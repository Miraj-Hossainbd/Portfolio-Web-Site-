<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Cuda - An awesome single page portfolio html template. easy web design and development. web design web develop. miraj hossain "> 
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cuda - An awesome single page portfolio html template</title>
    <link rel="shortcut icon" type="image/x-icon" href="resources/img/favicon.png">
    <!-- GOOGLE FONTS -->
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:300,400,600,700" rel="stylesheet">
    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <!-- VENDORS FILES -->
    <link rel="stylesheet" href="vendors/css/normalize.css">
    <link rel="stylesheet" href="vendors/css/grid.css">
    <!-- RESOURCES FILES -->
    <link rel="stylesheet" href="resources/css/style.css">
    <link rel="stylesheet" href="resources/css/responsive.css">
</head>
<body>
  
  <!--START HEADER SECTION-->

<header id="home">
    <nav>
        <div class="row">
            <a href="#">
                <img class="logo" src="resources/img/logo.png" alt="Cuda">
            </a>
            <ul class="main-nav">
                <li><a class="active" href="#home">home</a></li>
                <li><a href="#service">service</a></li>
                <li><a href="#teams">Teams</a></li>
                <li><a href="#skill">skill</a></li>
                <li><a href="#portfolio">portfolio</a></li>
                <li><a href="#testimonial">testimonial</a></li>
                <li><a href="#contact">contact</a></li>
            </ul>
            <div class="mobile-menu">
                <span onclick="openNav()">&#9776;</span>
                <div id="ournav" class="overlay">
                    <a href="javascript:void(0)" class="close-btn" onclick="closeNav()">&times;</a>
                    <div class="overlay-content">
                        <ul>
                            <li><a onclick="closeNav()" href="#home">home</a></li>
                            <li><a onclick="closeNav()" href="#service">service</a></li>
                            <li><a onclick="closeNav()" href="#teams">Teams</a></li>
                            <li><a onclick="closeNav()" href="#skill">skill</a></li>
                            <li><a onclick="closeNav()" href="#portfolio">portfolio</a></li>
                            <li><a onclick="closeNav()" href="#testimonial">testimonial</a></li>
                            <li><a onclick="closeNav()" href="#contact">contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div class="row">
        <div class="hero-text-box">
            <h1>Hi there! We are the new kids on the block and we build awesome websites and mobile apps.</h1>
            <a href="#contact" class="btn btn-hero">work with us!</a>
        </div>
    </div>
</header>

  <!--START HEADER SECTION-->

  <!-- START SERVICES SECTION-->

<section class="services-section js-sticky-menu" id="service">
    <div class="row">
         <h2>Services we provide</h2>
         <p class="littel-description">Wee are working with both individuals and business fromall over the globe to create awesome websites and applications.</p>
    </div>    
    <div class="row">
        <div class="col span_1_of_4 box">
            <img class="services-icon" src="resources/img/flag.png" alt="flag">
            <h3>Branding</h3>
            <p>Lorem ipsum dolor sit amet conse ctetur, adipi sicing elit. Ipsa eius accusamus corrupti?</p>
        </div>
        <div class="col span_1_of_4 box">
            <img class="services-icon" src="resources/img/crayon.png" alt="crayon">
            <h3>Design</h3>
            <p>Lorem ipsum dolor sit amet consect etur, adipi sicing elit. Ipsa eius adipisicing lorem.</p>
        </div>
        <div class="col span_1_of_4 box">
            <img class="services-icon" src="resources/img/gears.png" alt="gears">
            <h3>Development</h3>
            <p>Lorem ipsum dolor sit amet conse ctetur, adipis icing elit. Ipsa eius accusamus!</p>
        </div>
        <div class="col span_1_of_4 box">
            <img class="services-icon" src="resources/img/rocket.png" alt="rocket">
            <h3>Rocket Science</h3>
            <p>Lorem ipsum dolor sit amet cons ectetur, adipis icing elit. eius accusamus corrup.</p>
        </div>
    </div>
 </section>

  <!-- END SERVICES SECTION-->

  <!-- START TEAM SECTION-->

<section id="teams" class="team-section">
    <div class="row">
        <h2>Meet our beautiful team</h2>
        <p class="littel-description">We are a small team of designers and developers, who help brands with big ideas.</p>
    </div>
    <div class="row">
        <div class="col span_1_of_4 box">
            <img class="team-member" src="resources/img/1.jpg" alt="Miraj">
            <h3>Anne Hathaway</h3>
            <span class="role">CEO / Marketing Guru</span>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa in atque enim earum, quidem saepe reprehenderit ipsum itaque.</p>
            <div class="social-link">
                <ul>
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fas fa-envelope"></i></a></li>
                </ul>
            </div>
        </div> 
        <div class="col span_1_of_4 box">
            <img class="team-member" src="resources/img/2.jpg" alt="Miraj">
            <h3>Kate Upton</h3>
            <span class="role">Creative Director</span>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa in atque enim earum, quidem saepe reprehenderit ipsum itaque.</p>
            <div class="social-link">
                <ul>
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fas fa-envelope"></i></a></li>
                </ul>
            </div>
        </div> 
        <div class="col span_1_of_4 box">
            <img class="team-member" src="resources/img/3.jpg" alt="Miraj">
            <h3>Olivia Wilde</h3>
            <span class="role">Lead Designer</span>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa in atque enim earum, quidem saepe reprehenderit ipsum itaque.</p>
            <div class="social-link">
                <ul>
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fas fa-envelope"></i></a></li>
                </ul>
            </div>
        </div> 
        <div class="col span_1_of_4 box">
            <img class="team-member" src="resources/img/4.jpg" alt="Miraj">
            <h3>Ashley Greene</h3>
            <span class="role">SEO / Developer</span>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa in atque enim earum, quidem saepe reprehenderit ipsum itaque.</p>
            <div class="social-link">
                <ul>
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fas fa-envelope"></i></a></li>
                </ul>
            </div>
        </div> 
    </div>
</section>

  <!-- END TEAM SECTION-->

  <!-- START SKILL SECTION-->

<section id="skill" class="skill-section">
    <div class="row">
        <h2>We got skills!</h2>
        <p class="littel-description">Lorem ipsum dolor sit amet Lorem, ipsum dolor. consectetur adipisicing elit. Nulla, veniam eos. Sequi deleniti in eligendi, eius soluta vero.</p>
    </div>
    <div class="row">
        <div class="col span_1_of_4 box">
            <svg class="radial-progress web-design" data-percentage="90" viewBox="0 0 80 80">
                <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">90%</text>
            </svg>
            <h3>Web design</h3>
        </div> 
        <div class="col span_1_of_4 box">
            <svg class="radial-progress html-css" data-percentage="75" viewBox="0 0 80 80">
                <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">75%</text>
            </svg>
            <h3>Html / Css</h3>
        </div> 
        <div class="col span_1_of_4 box">
            <svg class="radial-progress graphic-design" data-percentage="70" viewBox="0 0 80 80">
                <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">70%</text>
            </svg>
            <h3>Graphic Design</h3>
        </div> 
        <div class="col span_1_of_4 box">
            <svg class="radial-progress ui-ux" data-percentage="85" viewBox="0 0 80 80">
                <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">85%</text>
            </svg>
            <h3>Ui / Ux</h3>
        </div> 
    </div>
</section>
  <!-- END SKILL SECTION-->

  <!-- START PORTFOLIO SECTION-->

<section id="portfolio" class="portfolio-section">
    <div class="row">
        <h2>Our portfolio</h2>
        <p class="littel-description">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolores provident esse, ex excepturi ducimus facere distinctio quam blanditiis.</p>
    </div>
    <div class="row">
        <div class="portfolio-filter">
            <button type="button" data-filter="all"> All </button>
            <button type="button" data-filter=".web">Web</button>
            <button type="button" data-filter=".apps">Apps</button>
            <button type="button" data-filter=".icons">Icons</button>
        </div>
    </div>
    <div class="row container-mixer">
        <div class="col span_1_of_2 box mix icons">
            <img class="portfolio-image" src="resources/img/portfolio1.png" alt="mock up">
            <h4> prespective mock-up</h4>
        </div>
        <div class="col span_1_of_2 box mix web icons">
            <img class="portfolio-image" src="resources/img/portfolio2.png" alt="mock up">
            <h4>Time zone app ui</h4>
        </div>
        <div class="col span_1_of_2 box mix apps web">
            <img class="portfolio-image" src="resources/img/portfoliO3.png" alt="mock up">
            <h4>Viro Media Player ui</h4>
        </div>
        <div class="col span_1_of_2 box mix apps icons">
            <img class="portfolio-image" src="resources/img/portfolio4.png" alt="mock up">
            <h4>Blog / Magazine Flat ui kit</h4>
        </div>
    </div>
    <!-- == HIDDEN LOAD MORE BUTTON HERE
    <div class="row">
        <a href="#" class="btn btn-load-more">Load more Projects</a>
    </div>
    == HIDDEN LOAD MORE BUTTON HERE -->
</section>

  <!-- END PORTFOLIO SECTION-->

  <!-- START TESTIMONIAL SECTION-->

<section id="testimonial" class="testimonial-section">
    <div class="row">
        <h2>What people say about us</h2>
        <p class="littel-description">Our client's love us!</p>
    </div>
    <div class="row">
        <div class="col span_1_of_2 box">
            <div class="client-photo">
                <img src="resources/img/1.jpg" alt="chanel iman">
            </div>
            <div class="client-review">
                <p>“Nullam dapibus blandit orci, viverra gravida dui lobortis eget. Maecenas fringilla urna eu nisl scelerisque.”</p>
                <h3>Chanel Iman</h3>
                <span class="role">CEO of Pinterast</span>
            </div>
        </div>
        <div class="col span_1_of_2 box">
            <div class="client-photo">
                <img src="resources/img/2.jpg" alt="chanel iman">
            </div>
            <div class="client-review">
                <p>“Vivamus luctus urna sed urna ultricies ac tempor dui sagittis. In condimentum facilisis porta. Lorem, ipsum.”</p>
                <h3>Ardina Lima</h3>
                <span class="role">Founder of Instagram</span>
            </div>
        </div>
        <div class="col span_1_of_2 box">
            <div class="client-photo">
                <img src="resources/img/3.jpg" alt="chanel iman">
            </div>
            <div class="client-review">
                <p>“Vivamus luctus urna sed urna ultricies ac tempor dui sagittis. In Lorem, ipsum. condimentum facilisis porta.”</p>
                <h3>ADRIANA LIMA</h3>
                <span class="role">Lead Designer at Behance</span>
            </div>
        </div>
        <div class="col span_1_of_2 box">
            <div class="client-photo">
                <img src="resources/img/4.jpg" alt="chanel iman">
            </div>
            <div class="client-review">
                <p>“Phasellus non purus vel arcu tempor commodo. Fusce semper, purus vel luctus molestie, risus sneque.”</p>
                <h3>EMMA STONE</h3>
                <span class="role">Co-Founder of Shazam</span>
            </div>
        </div>
    </div>
</section>

  <!-- END TESTIMONIAL SECTION-->

  <!--START CONTACT SECTION-->

<section id="contact" class="contact-section">
    <div class="row">
        <h2>GET IN TOUCH</h2>
        <p class="littel-description">1600 Pennsylvania Ave NW, Washington, DC 20500, United States of America. Tel: (202) 456-1111</p>
    </div>
    <div class="row">
        <form action="https://formspree.io/mirajh358@gmail.com" method="POST">
            <div class="row">
                <div class="col span_1_of_2">
                    <input type="text" name="Name" placeholder="Your Name *" required>
                </div>
                <div class="col span_1_of_2 input-email">
                    <input type="email" name="Email" placeholder="Your Email *" required>
                </div>
            </div>
            <div class="row">
                <textarea name="Text" cols="30" rows="8" placeholder="Your Text *"></textarea>
            </div>
            <div class="row">
                <input class="btn btn-submit" type="button" value="send message">
            </div>
        </form>
    </div>
</section>

  <!--END CONTACT SECTION-->
  
  <!--START FOOTER SECTION-->

<footer class="footer-section">
    <div class="row">
        <ul>
            <li><a href="#">Facebook</a></li>
            <li><a href="#">Twitter</a></li>
            <li><a href="#">google+</a></li>
            <li><a href="#">LinkedIn</a></li>
            <li><a href="#">Behance</a></li>
            <li><a href="#">Dribble</a></li>
            <li><a href="#">GitHub</a></li>
        </ul>
    </div>
</footer>

  <!--END FOOTER SECTION-->
  
   <!-- JS SCRIPTS -->
   
   <!--jquery cdn link here-->
  
    <script src="vendors/jquery/jquery-3.6.0.min.js"></script>
   <script src="vendors/js/html5shiv.min.js"></script>
   <script src="vendors/js/respond.min.js"></script>
   <script src="vendors/js/selectivizr-min.js"></script>
   <script src="vendors/js/jquery.waypoints.min.js"></script>
   <script src="vendors/js/mixitup.min.js"></script>
   <script src="resources/js/main.js"></script>
    
</body>
</html>